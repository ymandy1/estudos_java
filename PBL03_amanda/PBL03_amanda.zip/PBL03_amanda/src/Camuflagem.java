public interface Camuflagem {
    default void camuflar(int cor){

    }
}
